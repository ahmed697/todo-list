export interface Humain {
    name: string
    icon: string
}
